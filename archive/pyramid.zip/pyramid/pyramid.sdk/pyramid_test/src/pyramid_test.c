// =============================================================================
//  Program : pyramid_test.c
//  Author  : Chun-Jen Tsai
//  Date    : May/25/2020
// -----------------------------------------------------------------------------
//  Description:
//  This is a test program for the image down-sampler accelerator that can be
//  used for image-pyramid generation.
//
//  The program was tested using TeraTerm Pro as the terminal emulator. Once
//  the program is running one the Xilinx KC-705 development board, you can use
//  the menu command "File->Send file" to send a 640x480 input image to the system.
//  The scaled image(s) will be printed to the terminal. Therefore, you should
//  enable the logging function of TeraTerm Pro to store the output image into
//  a file. A DOS command-line program "txt2img" can then convert the output text
//  file to a PGM image file.
//
// -----------------------------------------------------------------------------
//  Revision information:
//
//  None.
// -----------------------------------------------------------------------------
//  License information:
//
//  This software is released under the BSD-3-Clause Licence,
//  see https://opensource.org/licenses/BSD-3-Clause for details.
//  In the following license statements, "software" refers to the
//  "source code" of the complete hardware/software system.
//
//  Copyright 2020,
//                    Embedded Intelligent Systems Lab (EISL)
//                    Deparment of Computer Science
//                    National Chiao Tung Uniersity
//                    Hsinchu, Taiwan.
//
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of the copyright holder nor the names of its contributors
//     may be used to endorse or promote products derived from this software
//     without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
// =============================================================================

#include <stdio.h>
#include <stdlib.h>
#include "xil_printf.h"
#include <xparameters.h>
#include "xil_cache.h"

volatile int *hw_active  = (int *) (XPAR_DOWN_SCALER_0_S00_AXI_BASEADDR + 0);  //trigger Down scaler
volatile int *dst_reg    = (int *) (XPAR_DOWN_SCALER_0_S00_AXI_BASEADDR + 4);  //scaled pixels address
volatile int *src_reg    = (int *) (XPAR_DOWN_SCALER_0_S00_AXI_BASEADDR + 8);  //source pixels address
volatile int *down_level = (int *) (XPAR_DOWN_SCALER_0_S00_AXI_BASEADDR + 12); //decimation rate: down_level/32

#define IN_W 640                 // source image width
#define IN_H 480                 // source image height
#define DOWN_LEVEL 20            // 8 ~ 31, decimation rate: down_level/32

unsigned int source_pixels[IN_W * IN_H];

void read_image_uart(unsigned int *image)
{
	int row, col, idx;
    unsigned int pix4;

    printf("Please enable TeraTerm log file, then send\n");
    printf("the PGM image thru the menu item File->Send file ...\n");

    // Skip the PGM image header. We assume that the
    //    header size is fixed at 15 bytes.
    for (idx = 0; idx < 15; idx++) inbyte();

    // Read the 640x480x8-bit image data.
    // The source image is stored upside-down in memory.
    for (row = IN_H-1; row >= 0; row--)
    {
    	for (col = 0; col < IN_W/4; col++)
		{
			pix4  = ((unsigned) inbyte() << 24);
			pix4 += ((unsigned) inbyte() << 16);
			pix4 += ((unsigned) inbyte() <<  8);
			pix4 += (unsigned) inbyte();
			image[row * IN_W/4 + col] = (unsigned int) pix4;
		}
    }
    printf("Finished reading the input image.\n");
}

int main()
{
    int row, col, idx;
    unsigned char *image;
    int scaled_width  = (IN_W*DOWN_LEVEL)/32; //scaled image width
    int scaled_height = (IN_H*DOWN_LEVEL)/32; //scaled image height
    unsigned int *scaled_pixels;

    Xil_DCacheDisable();

    read_image_uart(source_pixels);

    if ((scaled_pixels = malloc(scaled_width*scaled_height*sizeof(int))) == NULL)
    {
    	xil_printf("Error: out of memory!\r\n");
    	return -1;
    }
    for (idx = 0; idx < scaled_width * scaled_height / 4; idx++)
    {
        scaled_pixels[idx] = -1;  // initialize
    }

    *dst_reg = (int) scaled_pixels;
    *src_reg = (int) source_pixels;
    *down_level = DOWN_LEVEL;
    *hw_active = 1;             // trigger the HW IP
    while (*hw_active);         // busy-waiting until the HW is done

    // The scaled image is rotated 90 degree in memory. We must
    // rotate it back and send the output to the UART terminal.
    image = (unsigned char *) scaled_pixels;
    printf("IMG %dx%d:\n", scaled_width, scaled_height);
    for ( int i = 0 ; i < scaled_width * scaled_height ; i ++)
    {
        printf("%02x", image[i]);
        if (i % 4 == 3) printf("\n");
    }

    free(scaled_pixels);
    return 0;
}
